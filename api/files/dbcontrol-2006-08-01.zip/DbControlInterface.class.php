<?php

/**
* Interface for Database control PHP class
* @author Michal Palma <palmic at centrum dot cz>
* @copyleft (l) 2005-2006  Michal Palma
* @package DbControl
* @version 1.5
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
* @date 2006-01-11
*/
interface DbControlInterface
{

    //== constructors ====================================================================

    public function DbControl($task, $charset = "utf8");


    //== public functions ================================================================

    /**
    * Sets a query for database
    * @return void
    */
    public function setQuery(/*string*/ $query);

    /**
    * initiate a database query
    * @return DbResult
    */
    public function initiate();

    /**
    * Select working db schema
    * @return boolean
    */
    public function selectDb($dbName);

    /**
    * Return ID of last created Row
    * @return string
    */
    public function getLastId();

    /**
    * returns array with table column names and their data types
    * @return array
    */
    public function getTableColumns(/*string*/ $schemaName, /*string*/ $tableName);

    /**
    * Begin transaction sequence. (Check Your MySQL table types. Must be InnoDB, or BDB)
    * @return void
    */
    public function transactionStart($autoCommit = false);

    /**
    * Commit active transaction
    * @return void
    */
    public function transactionCommit();

    /**
    * Rollback active transaction
    * @return void
    */
    public function transactionRollback();

}

?>