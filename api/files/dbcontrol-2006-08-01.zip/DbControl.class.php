<?php

/**
* class to dealing with database resources independable on db platform
* @author Michal Palma <palmic at centrum dot cz>
* @copyleft (l) 2005-2006  Michal Palma
* @package DbControl
* @version 1.5
* @license http://opensource.org/licenses/gpl-license.php GNU Public License
* @date 2006-01-11
*/
class DbControl implements DbControlInterface
{

    //== Attributes ======================================================================

    /**
    * database query to initiate
    * @type string
    */
    protected $query;

    /**
    * Task identifier (config.xml settings ID)
    * @type string
    */
    protected $task;

    /**
    * Handler of shared attributes
    * @type DbStateHandler
    */
    protected $dbStateHandler;

    /**
    * Log on flag
    * @type boolean
    */
    protected $logOn;

    /**
    * Log handling object
    * @type DbLog
    */
    protected $DbLogH;
    
    /**
    * No result-cache flag
    * @type boolean
    */
    protected $noCache;

    //== constructors ====================================================================

    public function DbControl(/*String*/ $task, $charset = "utf8") {
        if (!is_string($task)) {
            throw new DbControlException("Ilegal parameter task. Must be string.");
        }
		$this->task = $task;
        try {
            $this->dbStateHandler = new DbStateHandler($task, $charset);
        }
        catch (Exception $e) {
            throw $e;
        }
    }


    //== destructors ====================================================================
    //== public functions ===============================================================

    public function setQuery(/*string*/ $query, /*boolean*/ $noCache = false) {
        if (!is_string($query)) {
            throw new DbControlException("Ilegal parameter query. Must be string.");
        }
        if (!is_bool($noCache)) {
            throw new DbControlException("Ilegal parameter noCache. Must be boolean.");
        }
        $this->noCache  = $noCache;
        $this->query    = $query;
    }

    public function initiate() {
        if (!is_string($this->getQuery())) {
            throw new DbControlException("No query to initiate!");
        }
        $query = $this->getQuery();
        if (func_num_args() > 0) {
            $arguments = func_get_args();
            for ($i = 1; $i <= count($arguments); $i++) {
                try {
                    if (!strstr($query, "<$i>")) {
                        throw new DbControlException("Number of replacement elements in query does not corresponds the number of parametres in initiate.");
                    }
                    $query = str_ireplace("<$i>", $arguments[$i - 1], $query);
                }
                catch (Exception $e) {
                    throw new DbControlException($e->getMessage() ."\nCheck the count of initiate parameters.");
                }
            }
        }
        if (eregi("<[[:digit:]]+>", $query)) {
            throw new DbControlException("Number of replacement elements does not corresponds the number of parametres in initiate. \n". $query);
        }
        try {
            $result = $this->dbStateHandler->getDbPlatform()->query($query);
			if ($this->isLogOn()) {
				$this->log("Query succesfully done.\n". $query);
			}
            if ($result) {
                if (is_resource($result)) {
                    $resultStateHandler = $this->dbStateHandler->getCopy();
                    if ($this->noCache) {
                        return new DbResultNoCache($result, $resultStateHandler);
                    }
                    return new DbResult($result, $resultStateHandler);
                }
                else {
                    return $result;
                }
            }
        }
        catch (Exception $e) {
            throw $e;
        }
    }

    public function selectDb($dbName) {
        try {
            $this->dbStateHandler->getDbPlatform()->selectDb($dbName);
			if ($this->isLogOn()) {
				$this->log("Database ". $dbName ." succesfully choosed.");
			}
        }
        catch (Exception $e) {
            throw $e;
        }
    }

    public function getLastId() {
        return $this->dbStateHandler->getDbPlatform()->getLastId();
    }

    public function getTableColumns($schemaName, $tableName) {
        return $this->dbStateHandler->getDbPlatform()->getTableColumns($schemaName, $tableName);
    }

    public function transactionStart($autoCommit = false) {
        try {
            $this->dbStateHandler->getDbPlatform()->transactionStart($autoCommit);
        }
        catch (Exception $e) {
            throw $e;
        }
    }

    public function transactionCommit() {
        try {
            $this->dbStateHandler->getDbPlatform()->transactionCommit();
        }
        catch (Exception $e) {
            throw $e;
        }
    }

    public function transactionRollback() {
        try {
            $this->dbStateHandler->getDbPlatform()->transactionRollback();
        }
        catch (Exception $e) {
            throw $e;
        }
    }


    //== protected functions =============================================================

    /**
    * getter for query
    * @return string
    */
    protected function getQuery() {
        return $this->query;
    }

    /**
    * Log on?
    * @return boolean
    */
    protected function isLogOn() {
		if (is_bool($this->logOn)) {
		  	return $this->logOn;
		}
		$DbCfg = new DbCfg();
		$logOnCfg = $DbCfg->get($this->dbStateHandler->getTask() ."/logon");
		if ($logOnCfg) {
			if (current($logOnCfg) > 0) {
			  	$this->logOn = true;
			}
			else {
			  	$this->logOn = false;
			}
		}
		return $this->logOn;
	}
	
    /**
    * getter for DbLog object
    * @return DbLog
    */
    protected function getDbLogH() {
	  	if (is_a($this->DbLogH, "DbLog")) {
		    return $this->DbLogH;
		}
		$this->DbLogH = new DbLog;
		return $this->DbLogH;
	}

    /**
    * do log into a log file
    * @return void
    */
    protected function log(/*String*/ $log) {
        if (!is_string($log)) {
            throw new DbControlException("Ilegal parameter log. Must be string.");
        }
        $add = "Current task ID: ". $this->task ."\n";
		$this->getDbLogH()->log($log ."\n". $add);
	}	
}

?>