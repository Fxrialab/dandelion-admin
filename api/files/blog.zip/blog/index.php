<?php

require __DIR__.'/lib/base.php';

//F3::set('CACHE',TRUE);
F3::set('DEBUG',3);
F3::set('UI','ui/');

F3::set('DB',
	new DB(
		'mysql:host=localhost;port=3306;dbname=YourDatabaseName',
		'YourUserName',
		'YourPassword'
	)
);

F3::route('GET /',
	function () {
		F3::set('html_title','Home Page');
		$article=new Axon('article');
		F3::set('list',$article->afind());
		F3::set('content','blog_home.html');
		echo Template::serve('layout.html');	
	}
);
	
F3::route('GET /view/@id',
	function () {
		$id = F3::get('PARAMS["id"]');
		$article=new Axon('article');
		$article->load("id='$id'");
		F3::set('html_title',$article->title);
		// Populate POST global with retrieved values
		$article->copyTo('POST');
		F3::set('content','blog_detail.html');
		echo Template::serve('layout.html');
	}
);

F3::route('GET /admin',
	function () {
		F3::set('html_title','My Blog Administration');
		$article=new Axon('article');
		$list=$article->afind();
		F3::set('list',$list);
		
		F3::set('AUTH',array('table'=>'user','id'=>'name','pw'=>'password'));
		$auth = Auth::basic('sql');
		if ($auth) {
			//set the session so user stays logged in
			F3::set('SESSION.user',$auth->name);
			F3::set('content','admin_home.html');
		} else {
			F3::set('content','security.html');
		}
		echo Template::serve('layout.html');	
	}
);

F3::route('GET /admin/add',
	function() {
		F3::set('html_title','My Blog Create');
		F3::set('content','admin_edit.html');
		if (!F3::get('SESSION.user')) F3::set('content','security.html');
		echo Template::serve('layout.html');
	}
);

F3::route('GET /admin/edit/@id',
	function() {
		F3::set('html_title','My Blog Edit');
		$id = F3::get('PARAMS["id"]');
		$article=new Axon('article');
		$article->load("id='$id'");
		$article->copyTo('POST');
		F3::set('content','admin_edit.html');
		echo Template::serve('layout.html');
	}
);

//this processes the form input
F3::route('POST /admin/edit/@id','edit');
F3::route('POST /admin/add','edit');
//don't use a lambda function here as the same function can be used to
//add or edit a record
	function edit() {
		// Reset previous error message, if any
		F3::clear('message');
		$id = F3::get('PARAMS["id"]');
		$article=new Axon('article');
		//load in the article, set new values then save
		//if we don't load it first axon will do an insert instead of update
		if ($id) $article->load("id='$id'");
		//overwrite with values just submitted
		$article->copyFrom('POST');
		$article->timestamp=date("Y-m-d H:i:s");
		$article->save();
		// Return to admin home page, new blog entry should now be there
		F3::reroute('/admin');
	}

F3::route('GET /admin/delete/@id',
	function() {
		$id = F3::get('PARAMS["id"]');
		$article=new Axon('article');
		$article->load("id='$id'");
		$article->erase();
		F3::reroute('/admin');
	}
);
		

F3::run();

?>
