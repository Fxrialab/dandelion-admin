<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<form class="ink-form" style="padding: 10px 0">
    <div class="control-group">
        <label for="name" class="large-30 align-right">Email</label>
        <div class="control large-70">
            <input type="text" name="oldPassword">
        </div>
    </div>
    <div class="control-group column-group">
        <input type="submit" value="Forgot" class="ink-button red" style="float: right">
        <input type="button" value="Back" class="ink-button changePassword" style="float: right">
    </div>
</form>