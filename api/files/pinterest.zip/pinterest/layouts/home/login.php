<?php
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<form class="ink-form" style="padding: 5px; background-color: #fff">
    <div class="column-group">
        <label class="large-25">Email</label>
        <input type="text" class="large-75">
    </div>
    <div class="column-group">
        <label class="large-25">Password</label>
        <input type="text" class="large-75">
    </div>
    <div style="margin: 0; background:#e5e5e5; padding: 5px 10px; text-align: right; margin: 0 -15px -5px;">
        <a href="#" class="ink-button">Login</a>
        <button class="ink-button" id="submit-post">SignUp</button>
    </div>
</form>