<div class="control-group uiCreateDB large-80 push-center">
    <span>Create DB is success, please delete installController file</span>
</div>