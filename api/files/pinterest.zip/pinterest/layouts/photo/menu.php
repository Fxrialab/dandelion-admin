<?php
/**
 * Created by fxrialab team
 * Author: Uchiha
 * Date: 10/4/13 - 10:25 AM
 * Project: userwired Network - Version: 1.0
 */
?>
<div class="menuPhoto">
    <li class="linkPhoto" id="navPhotos">
        <a href="/content/myPhoto" id="photos_all" style="color: white;">Your Photos</a>
    </li>
    <li class="linkPhoto" id="navAlbums">
        <a href="/content/photo/myAlbum" id="photos_albums">Albums</a>
    </li>
</div>
