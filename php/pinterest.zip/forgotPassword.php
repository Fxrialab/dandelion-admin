
<div class="column-group">
    <div class="large-40 medium-100 small-100 push-center">
        <form class="ink-form top-space formLogin" method="post" action="/forgotPassword" id="fmForgotPassword">
            <div><h2>Forgot Password</h2></div>
            <div class="title">
                <span>This form help you return your password. Please, enter your email for search</span>
            </div>
            <div class="column-group">
                <label class="large-25">Email</label>
                <input type="text" class="large-75" name="email"  placeholder="Your Email">
            </div>

            <div class="footerBox column-group">
                   <input type="submit" class="ink-button push-right" value="Search">
                <a class="ink-button push-right" href="/">Cancel</a>
            </div>
        </form>

    </div>
</div>

